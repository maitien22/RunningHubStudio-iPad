# RunningHub Studio iPad — SwiftUI native (source)

Ứng dụng iPadOS **native**, không phải PWA, gọi API RunningHub trực tiếp. Không cần PC hoặc VPS để gửi tác vụ khi ứng dụng đang mở.

## Cài lên iPad

**Bắt buộc có Mac với Xcode và Apple ID để build/ký ứng dụng** (hoặc dùng dịch vụ build macOS do anh kiểm soát). Windows không build và ký iPadOS app native trực tiếp bằng Xcode.

1. Cài Xcode mới hỗ trợ iPadOS 17+ trên Mac. Cài XcodeGen (`brew install xcodegen`).
2. Giải nén dự án, mở Terminal trong thư mục `RunningHubStudio_iPad` và chạy `xcodegen generate`.
3. Mở `RunningHubStudio.xcodeproj` trong Xcode.
4. Chọn target RunningHubStudio → Signing & Capabilities → Team là Apple ID của anh; đổi Bundle Identifier nếu trùng.
5. Kết nối iPad bằng cáp, chọn iPad làm Run Destination; bật Developer Mode trên iPad nếu được yêu cầu.
6. Bấm Run trong Xcode. Nếu sử dụng Apple ID miễn phí, chữ ký có thể hết hạn sau 7 ngày; muốn phân phối TestFlight cần Apple Developer Program.
7. Mở app trên iPad → API Key → nhập và lưu → Kiểm tra kết nối. Vào Workflow, tạo workflow ID và node mapping chính xác. Vào Tạo video → chọn ảnh/video từ Files → Gửi.
8. Lịch sử hiển thị trạng thái/taskId và file đã tải; bấm Chia sẻ / lưu video để lưu vào Files/Photos theo tùy chọn hệ thống.

## Quan trọng

- Không có API Key thật trong dự án. Không có video giả, tiến độ giả.
- Gọi API thật: `accountStatus`, `upload`, `create`, `status`, `outputs`.
- API Key lưu trong iPad Keychain. Workflow và lịch sử lưu JSON cục bộ trong Documents.
- File upload giới hạn 30 MB theo bản tích hợp hiện tại; các workflow khác nhau cần ánh xạ node khác nhau.
- Trên iPad, tác vụ RunningHub vẫn có thể tiếp tục ở server khi đóng app, nhưng **iPadOS không bảo đảm polling/tải video nền**. Mở lại app, vào Lịch sử → Theo dõi lại.
- Các job trước khi có `taskId` có thể không khôi phục an toàn khi app bị đóng; không tự gửi lại để tránh tính phí trùng.
- Hàng đợi hiện thực thi các job mới bằng Swift concurrency, **chưa có giới hạn tuần tự hay điều phối queue bền vững**. Không nhấn gửi nhiều lần khi chưa có taskId.
- Các response shape của RunningHub có thể thay đổi theo loại API Key/workflow; cần kiểm thử bằng tài khoản thật trước khi phát hành.
- Mã nguồn này **chưa được build/test trên Xcode hoặc iPad thực**, không có IPA đã ký.

## Kiểm thử

Trong Xcode chọn Product → Test để chạy 2 unit tests. Kiểm thử end-to-end cần API Key thật và workflow đã xác nhận node mapping; tác vụ có thể phát sinh chi phí.

## API

https://www.runninghub.ai/runninghub-api-doc-en/
