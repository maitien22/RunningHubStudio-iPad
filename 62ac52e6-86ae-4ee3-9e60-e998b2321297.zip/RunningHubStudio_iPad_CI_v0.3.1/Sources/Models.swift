import Foundation

struct NodeInput: Codable, Identifiable, Hashable {
    var id: UUID = UUID()
    var nodeId: String = ""
    var fieldName: String = ""
    var fieldValue: String = ""
}
struct Workflow: Codable, Identifiable, Hashable {
    var id: UUID = UUID()
    var name: String = ""
    var workflowId: String = ""
    var nodes: [NodeInput] = []
}
struct Job: Codable, Identifiable {
    var id: UUID = UUID()
    var workflowName: String
    var taskId: String? = nil
    var status: String = "QUEUED"
    var error: String? = nil
    var outputFiles: [String] = []
    var created: Date = Date()
}
struct APIError: LocalizedError {
    let message: String
    var errorDescription: String? { message }
}
