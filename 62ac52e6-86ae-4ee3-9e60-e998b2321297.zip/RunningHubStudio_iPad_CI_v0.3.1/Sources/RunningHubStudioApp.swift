import SwiftUI
import UniformTypeIdentifiers

@main struct RunningHubStudioApp:App {
    @StateObject private var store=StudioStore()
    var body:some Scene {WindowGroup {MainView().environmentObject(store)}}
}
struct MainView:View {
    @EnvironmentObject var store:StudioStore
    @State private var selection=0
    var body:some View {
        TabView(selection:$selection) {
            GenerateView().tabItem{Label("Tạo video",systemImage:"film")}.tag(0)
            WorkflowListView().tabItem{Label("Workflow",systemImage:"square.stack.3d.up")}.tag(1)
            HistoryView().tabItem{Label("Lịch sử",systemImage:"clock")}.tag(2)
            SettingsView().tabItem{Label("API Key",systemImage:"key")}.tag(3)
        }.tint(.cyan)
    }
}
struct SettingsView:View {
    @EnvironmentObject var store:StudioStore
    var body:some View {NavigationStack {Form {
        Section("RunningHub API Key") {
            SecureField("Nhập API Key",text:$store.apiKeyInput)
            Button("Lưu vào iPad Keychain"){store.saveKey()}
            Button("Kiểm tra kết nối thật"){Task{await store.checkKey()}}.disabled(store.busy)
        }
        Section("Phản hồi") {Text(store.message).textSelection(.enabled)}
        Section("Bảo mật") {Text("API Key chỉ được lưu trong Keychain thiết bị. Ứng dụng gửi khóa trực tiếp tới RunningHub qua HTTPS.")}
    }.navigationTitle("Cài đặt")}}
}
struct WorkflowListView:View {
    @EnvironmentObject var store:StudioStore
    @State private var showingNew=false
    var body:some View {NavigationStack {List {
        ForEach($store.workflows) {$workflow in NavigationLink {WorkflowEditor(workflow:$workflow)} label: {
            VStack(alignment:.leading){Text(workflow.name.isEmpty ? "Chưa đặt tên":workflow.name).font(.headline);Text(workflow.workflowId).font(.caption).foregroundStyle(.secondary)}
        }}.onDelete{store.workflows.remove(atOffsets:$0)}
    }.navigationTitle("Workflow").toolbar {Button {store.workflows.append(Workflow(name:"Workflow mới"))} label:{Image(systemName:"plus")}}}}
}
struct WorkflowEditor:View {
    @Binding var workflow:Workflow
    var body:some View {Form {
        Section("Thông tin") {TextField("Tên workflow",text:$workflow.name);TextField("Workflow ID",text:$workflow.workflowId).textInputAutocapitalization(.never)}
        Section("Ánh xạ node") {
            ForEach($workflow.nodes) {$node in
                VStack(alignment:.leading,spacing:8) {
                    TextField("nodeId",text:$node.nodeId)
                    TextField("fieldName",text:$node.fieldName)
                    TextField("fieldValue hoặc @IMAGE / @VIDEO",text:$node.fieldValue)
                }.padding(.vertical,6)
            }.onDelete{workflow.nodes.remove(atOffsets:$0)}
            Button("Thêm node"){workflow.nodes.append(NodeInput())}
        }
        Section {Text("Các nodeId và fieldName phải lấy từ workflow thực trên RunningHub. @IMAGE và @VIDEO là vị trí thay bằng file upload.")}
    }.navigationTitle("Cấu hình node")}
}
struct GenerateView:View {
    @EnvironmentObject var store:StudioStore
    @State private var selectedID:UUID?
    @State private var image:URL?
    @State private var video:URL?
    @State private var pickImage=false
    @State private var pickVideo=false
    var body:some View {NavigationStack {Form {
        Section("Workflow") {
            Picker("Chọn workflow",selection:$selectedID) {
                Text("Chọn...").tag(nil as UUID?)
                ForEach(store.workflows){w in Text(w.name).tag(Optional(w.id))}
            }
        }
        Section("Tệp tham chiếu") {
            Button(image == nil ? "Chọn ảnh từ Files":"Ảnh: \(image!.lastPathComponent)"){pickImage=true}
            Button(video == nil ? "Chọn video từ Files":"Video: \(video!.lastPathComponent)"){pickVideo=true}
        }
        Section {
            Button("GỬI TẠO VIDEO THẬT") {
                guard let w=store.workflows.first(where:{$0.id==selectedID}) else {return}
                store.enqueue(w,image:image,video:video)
            }.disabled(selectedID == nil)
        }
        Section("Lưu ý") {Text("Tác vụ được gửi trực tiếp tới RunningHub và có thể phát sinh phí. Để tiếp tục theo dõi khi mở lại ứng dụng, vào Lịch sử → Theo dõi lại. iPadOS không bảo đảm polling liên tục khi ứng dụng đóng.")}
    }.navigationTitle("RunningHub Studio")
      .fileImporter(isPresented:$pickImage,allowedContentTypes:[.image]){if case .success(let url)=$0 {image=url}}
      .fileImporter(isPresented:$pickVideo,allowedContentTypes:[.movie,.video,.mpeg4Movie]){if case .success(let url)=$0 {video=url}}
    }}
}
struct HistoryView:View {
    @EnvironmentObject var store:StudioStore
    var body:some View {NavigationStack {List(store.jobs){job in
        VStack(alignment:.leading,spacing:8) {
            HStack {Text(job.workflowName).font(.headline);Spacer();Text(job.status).font(.caption).foregroundStyle(.secondary)}
            if let task=job.taskId {Text("Task: \(task)").font(.caption).textSelection(.enabled)}
            if let error=job.error {Text(error).font(.caption).foregroundStyle(.red)}
            ForEach(job.outputFiles,id:\.self){file in
                ShareLink(item:URL(fileURLWithPath:file)){Label("Chia sẻ / lưu video",systemImage:"square.and.arrow.up")}
            }
            if job.taskId != nil && job.status != "DOWNLOADED" {
                Button("Theo dõi lại / lấy kết quả"){Task{await store.resume(job.id)}}
            }
        }.padding(.vertical,6)
    }.navigationTitle("Hàng đợi & lịch sử")}}
}
