import Foundation
import SwiftUI

@MainActor final class StudioStore:ObservableObject {
    @Published var workflows:[Workflow] = [] {didSet {persist()}}
    @Published var jobs:[Job] = [] {didSet {persist()}}
    @Published var apiKeyInput = ""
    @Published var message = ""
    @Published var busy = false
    private let file = FileManager.default.urls(for:.documentDirectory,in:.userDomainMask)[0].appendingPathComponent("studio.json")
    struct Snapshot:Codable {let workflows:[Workflow];let jobs:[Job]}
    init() {
        if let data=try? Data(contentsOf:file),let snapshot=try? JSONDecoder().decode(Snapshot.self,from:data) {workflows=snapshot.workflows;jobs=snapshot.jobs}
        apiKeyInput = Keychain.read(account:"runninghub_api") ?? ""
    }
    func persist() {
        if let data=try? JSONEncoder().encode(Snapshot(workflows:workflows,jobs:jobs)) {try? data.write(to:file,options:.atomic)}
    }
    func saveKey() {
        do {try Keychain.save(apiKeyInput.trimmingCharacters(in:.whitespacesAndNewlines),account:"runninghub_api");message="API Key đã lưu vào Keychain"}
        catch {message=error.localizedDescription}
    }
    func checkKey() async {
        busy=true;defer{busy=false}
        do {let result=try await api().account();message="API trả lời: \(result)"}
        catch {message=error.localizedDescription}
    }
    func api() throws -> RunningHubAPI {
        guard let key=Keychain.read(account:"runninghub_api"), !key.isEmpty else {throw APIError(message:"Lưu API Key trước")}
        return RunningHubAPI(key:key)
    }
    func enqueue(_ workflow:Workflow,image:URL?,video:URL?) {
        let job=Job(workflowName:workflow.name)
        jobs.insert(job,at:0)
        Task {await execute(job.id,workflow:workflow,image:image,video:video)}
    }
    private func change(_ id:UUID,_ update:(inout Job)->Void) {
        guard let i=jobs.firstIndex(where:{$0.id==id}) else{return}
        update(&jobs[i])
    }
    func execute(_ id:UUID,workflow:Workflow,image:URL?,video:URL?) async {
        do {
            let client=try api()
            change(id){$0.status="UPLOADING"}
            var nodes=workflow.nodes
            if nodes.contains(where:{$0.fieldValue=="@IMAGE"}) {
                guard let image else {throw APIError(message:"Thiếu ảnh tham chiếu")}
                let uploaded=try await client.upload(url:image)
                nodes=nodes.map{var n=$0;if n.fieldValue=="@IMAGE" {n.fieldValue=uploaded};return n}
            }
            if nodes.contains(where:{$0.fieldValue=="@VIDEO"}) {
                guard let video else {throw APIError(message:"Thiếu video tham chiếu")}
                let uploaded=try await client.upload(url:video)
                nodes=nodes.map{var n=$0;if n.fieldValue=="@VIDEO" {n.fieldValue=uploaded};return n}
            }
            change(id){$0.status="SUBMITTING"}
            let task=try await client.create(workflow:workflow,nodes:nodes)
            change(id){$0.taskId=task;$0.status="SUBMITTED"}
            await monitor(id,task:task)
        } catch {change(id){$0.status="ERROR";$0.error=error.localizedDescription}}
    }
    func resume(_ id:UUID) async {
        guard let job=jobs.first(where:{$0.id==id}),let task=job.taskId else {return}
        await monitor(id,task:task)
    }
    func monitor(_ id:UUID,task:String) async {
        do {
            let client=try api()
            for _ in 0..<240 {
                let status=try await client.status(taskId:task)
                change(id){$0.status=status}
                if ["SUCCESS","SUCCEEDED","COMPLETED","FINISHED"].contains(status) {
                    let links=try await client.outputs(taskId:task)
                    guard !links.isEmpty else {change(id){$0.status="OUTPUT_PENDING"};return}
                    change(id){$0.status="DOWNLOADING"}
                    var files:[String]=[]
                    for url in links {files.append(try await client.download(url))}
                    change(id){$0.status="DOWNLOADED";$0.outputFiles=files}
                    return
                }
                if ["FAILED","ERROR","CANCELED"].contains(status) {return}
                try await Task.sleep(for:.seconds(5))
            }
            change(id){$0.status="POLL_TIMEOUT"}
        } catch {change(id){$0.status="RETRY_REQUIRED";$0.error=error.localizedDescription}}
    }
}
