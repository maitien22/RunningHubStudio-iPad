import Foundation

struct RunningHubAPI {
    let key: String
    var baseURL = URL(string:"https://www.runninghub.ai")!
    var session: URLSession = .shared

    func post(_ path: String, body: [String:Any]) async throws -> [String:Any] {
        var request = URLRequest(url:baseURL.appendingPathComponent(path))
        request.httpMethod = "POST"
        request.setValue("Bearer \(key)", forHTTPHeaderField:"Authorization")
        request.setValue("application/json", forHTTPHeaderField:"Content-Type")
        var payload = body; payload["apikey"] = key
        request.httpBody = try JSONSerialization.data(withJSONObject:payload)
        return try await execute(request)
    }
    func execute(_ request: URLRequest) async throws -> [String:Any] {
        let (data,response) = try await session.data(for:request)
        guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
            throw APIError(message:"HTTP \((response as? HTTPURLResponse)?.statusCode ?? 0): \(String(data:data,encoding:.utf8) ?? "")")
        }
        guard let object = try JSONSerialization.jsonObject(with:data) as? [String:Any] else {throw APIError(message:"API returned invalid JSON")}
        if let code = object["code"] as? Int, code != 0 {throw APIError(message:"RunningHub \(code): \(object["msg"] ?? object["message"] ?? "Unknown error")")}
        return object
    }
    func account() async throws -> [String:Any] {try await post("uc/openapi/accountStatus",body:[:])}
    func upload(url:URL) async throws -> String {
        let scoped = url.startAccessingSecurityScopedResource()
        defer {if scoped {url.stopAccessingSecurityScopedResource()}}
        let data = try Data(contentsOf:url)
        guard data.count <= 30*1024*1024 else {throw APIError(message:"File exceeds 30 MB API upload limit")}
        let boundary = UUID().uuidString
        var request = URLRequest(url:baseURL.appendingPathComponent("task/openapi/upload"))
        request.httpMethod = "POST"
        request.setValue("Bearer \(key)",forHTTPHeaderField:"Authorization")
        request.setValue("multipart/form-data; boundary=\(boundary)",forHTTPHeaderField:"Content-Type")
        var body = Data()
        func append(_ s:String) {body.append(Data(s.utf8))}
        append("--\(boundary)\r\nContent-Disposition: form-data; name=\"apikey\"\r\n\r\n\(key)\r\n")
        append("--\(boundary)\r\nContent-Disposition: form-data; name=\"file\"; filename=\"\(url.lastPathComponent.replacingOccurrences(of:"\"",with:"_"))\"\r\nContent-Type: application/octet-stream\r\n\r\n")
        body.append(data); append("\r\n--\(boundary)--\r\n")
        request.httpBody = body
        let result = try await execute(request)
        let content = result["data"] as? [String:Any] ?? result
        for name in ["fileName","fileUrl","url","name"] {if let v = content[name] as? String, !v.isEmpty {return v}}
        if let v = result["data"] as? String, !v.isEmpty {return v}
        throw APIError(message:"Upload response has no recognized file reference: \(result)")
    }
    func create(workflow:Workflow, nodes:[NodeInput]) async throws -> String {
        let inputs = nodes.map {["nodeId":$0.nodeId,"fieldName":$0.fieldName,"fieldValue":$0.fieldValue]}
        let result = try await post("task/openapi/create",body:["workflowId":workflow.workflowId,"nodeInfoList":inputs,"addMetadata":true])
        let content = result["data"] as? [String:Any] ?? result
        guard let id = (content["taskId"] as? String) ?? (content["task_id"] as? String) else {throw APIError(message:"Create response missing taskId: \(result)")}
        return id
    }
    func status(taskId:String) async throws -> String {
        let result = try await post("task/openapi/status",body:["taskId":taskId])
        let content = result["data"] as? [String:Any] ?? result
        return String(describing:content["taskStatus"] ?? content["status"] ?? "UNKNOWN").uppercased()
    }
    func outputs(taskId:String) async throws -> [URL] {
        let result = try await post("task/openapi/outputs",body:["taskId":taskId])
        var found:[URL] = []
        func scan(_ object:Any) {
            if let dict = object as? [String:Any] {
                for (k,v) in dict {
                    if ["fileUrl","url","downloadUrl"].contains(k), let s=v as? String, let url=URL(string:s), url.scheme=="https" {found.append(url)}
                    else {scan(v)}
                }
            } else if let arr=object as? [Any] {arr.forEach{scan($0)}}
        }
        scan(result)
        return Array(Set(found))
    }
    func download(_ url:URL) async throws -> String {
        guard url.scheme == "https" else {throw APIError(message:"Only HTTPS downloads allowed")}
        let (temp,response) = try await session.download(from:url)
        guard let http=response as? HTTPURLResponse, (200...299).contains(http.statusCode) else {throw APIError(message:"Download HTTP error")}
        let folder = FileManager.default.urls(for:.documentDirectory,in:.userDomainMask)[0].appendingPathComponent("Videos",isDirectory:true)
        try FileManager.default.createDirectory(at:folder,withIntermediateDirectories:true)
        let ext = url.pathExtension.isEmpty ? "mp4" : url.pathExtension
        let dest = folder.appendingPathComponent("\(UUID().uuidString).\(ext)")
        try FileManager.default.moveItem(at:temp,to:dest)
        return dest.path
    }
}
