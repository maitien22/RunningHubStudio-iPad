#!/bin/sh
set -eu
for f in Sources/*.swift Tests/*.swift; do swiftc -frontend -parse "$f"; done
python3 - <<'PY'
from pathlib import Path
p=Path('.github/workflows/ios-build.yml').read_text()
assert 'CODE_SIGNING_ALLOWED=NO' in p
assert 'iphonesimulator' in p
assert 'upload-artifact@v4' in p
assert 'workflow_dispatch:' in p
print('PASS: Swift syntax and CI configuration assertions')
PY
