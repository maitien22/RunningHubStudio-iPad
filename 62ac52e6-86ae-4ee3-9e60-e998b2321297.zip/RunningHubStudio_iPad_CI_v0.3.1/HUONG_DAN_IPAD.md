# RunningHub Studio iPad — CI v0.3.1

## Trạng thái và giới hạn
- GitHub Actions này **chỉ build bản Simulator chưa ký**. File Simulator không thể cài lên iPad thật.
- Apple ID miễn phí không cho phân phối qua TestFlight và không cung cấp chứng chỉ phân phối để ký IPA bằng GitHub Actions.
- Muốn cài ứng dụng native trên iPad thật với Apple ID miễn phí: cần Mac/Xcode (có thể mượn/thuê Mac từ xa có quyền truy cập thiết bị phù hợp), đăng nhập Personal Team, ghép nối thiết bị và cài. Chữ ký miễn phí hết hạn sau 7 ngày.
- Nếu chỉ có iPad và không có Mac, lựa chọn khả thi ngay là PWA qua HTTPS; hoặc đăng ký Apple Developer Program rồi cấu hình signing/TestFlight trên Mac cloud.

## Thao tác trên Safari iPad
1. Mở github.com, đăng nhập, chọn dấu + > New repository > đặt tên `RunningHubStudio-iPad` > Private > Create repository.
2. Tải ZIP gói này vào ứng dụng Files và giải nén. Để tải cả cây thư mục lên GitHub dễ hơn, dùng ứng dụng Git client iPad hỗ trợ import thư mục và push; giao diện web GitHub có thể tải nhiều file nhưng việc giữ cấu trúc thư mục cần kiểm tra kỹ.
3. Trong repository, kiểm tra `.github/workflows/ios-build.yml`, `project.yml`, `Sources/` và `Tests/` đã tồn tại.
4. Vào tab Actions > `iPad SwiftUI CI (unsigned)` > Run workflow > Run workflow.
5. Xem job `build`: nếu đỏ, mở bước `Build iPad simulator` và xem log; nếu xanh, tải artifact `ios-build-results`.
6. Không tìm cách cài file `RunningHubStudio-Simulator-UNSIGNED.zip` lên iPad: nó chỉ dành cho Simulator.

## Để cài iPad thật
- Apple ID miễn phí + Xcode trên Mac: Signing & Capabilities > Personal Team > chọn iPad đã kết nối > Run; cấp quyền Developer Mode khi được hỏi. Gia hạn sau 7 ngày.
- Nếu mua Apple Developer Program: cấu hình chứng chỉ và provisioning profile qua tài khoản của chính anh, thiết lập App Store Connect và TestFlight. Không đưa Apple ID, mật khẩu, khóa riêng, API Key RunningHub vào GitHub repository.

## Lưu ý ứng dụng v0.3
- Chưa có bằng chứng build Xcode thành công, chưa test RunningHub end-to-end.
- `StudioStore.enqueue` khởi chạy Task ngay, **không phải hàng đợi tuần tự bền vững**.
- iPadOS có thể tạm dừng việc theo dõi tác vụ khi ứng dụng chạy nền.
- Chỉ cấu hình node theo workflow thực tế; không tự suy đoán node ID.
