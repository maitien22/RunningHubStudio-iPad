import XCTest
@testable import RunningHubStudio
final class RunningHubStudioTests:XCTestCase {
    func testNodeMarkersAndCodable() throws {
        let workflow=Workflow(name:"Motion",workflowId:"123",nodes:[NodeInput(nodeId:"7",fieldName:"image",fieldValue:"@IMAGE")])
        let decoded=try JSONDecoder().decode(Workflow.self,from:JSONEncoder().encode(workflow))
        XCTAssertEqual(decoded.nodes.first?.fieldValue,"@IMAGE")
        XCTAssertEqual(decoded.workflowId,"123")
    }
    func testJobDefaults() {
        XCTAssertEqual(Job(workflowName:"Test").status,"QUEUED")
    }
}
